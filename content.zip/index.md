---
title: Home
Draft: false
tags:
  - Category/Home
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
Publish: true
---
Welkom [[Mels]], [[Anna]], [[Olivier]], [[Quinten]], [[Nick]] of [[Emre]]! 
Ben jij dat niet. WTF! QUINTIJN HEB JE DIT OOK GEVONDEN. 

----
De Belangerijkste Tabs voor nu:
* [[Whispers]]:
	* [[Dan]]
	* [[Flappie]]
	* [[Arsan]]
	* [[Sid]]  

* [[Plekken]] in [[Solesticea]]

---

En natuurlijk sessie journaals dat is een combinatie van mijn aantekening plus tips en een korte bullet points met wat er gebeurt is:

* [[Sol Sessies]] :
	* [[Sol 1]]
	* [[Sol 2]]
	* [[Sol 3]]
	* [[Sol 4]]
	* [[Sol 5]] 


Vragen met antwoord voor DM's of spelers kunnen hier gevonden worden:
  * [[Vragen]]

---

Wil je hieraan meewerken of heb je opmerking/vragen mail dan naar:
admin@emrekadirtiren.eu.org