---
title: Flappie
Draft: 
tags:
  - Category/Individual
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
## Overview
**Alignment**: 
**Gender**: 
**Race**: 
**Class**:
**Age**: 
**Character Role**: Main Character

| STR   | DEX   | CON   | WIS   | INT   | CHA   |
| ----- | ----- | ----- | ----- | ----- | ----- |
| 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) |
### Portrait
![[.webp|222]]

# Story
## Personal Life

## Professional Life

## Background
**Birth Date**: Monday, 1 January -20000 12:00:00 AM
**Marriage Date**: Monday, 1 January -20000 12:00:00 AM
**Death Date**: Monday, 1 January -20000 12:00:00 AM

## Additional Details

