---
title: Dan
Draft: false
tags:
  - Category/Individual
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---

## Overview
**Alignment**: Neutral Good
**Gender**: Male
**Race**: [[Aarakocra]] 
**Class**: Sorcerer
**Age**: 15
**Alignment**: Neutral Good


### Placeholder Portrait
![[Dan-20240310222702113.webp|235]]



## Profile
**Appearance **:

| STR    | DEX    | CON    | WIS    | INT    | CHA    |
| ------ | ------ | ------ | ------ | ------ | ------ |
| 14(+2) | 16(+3) | 19(+4) | 13(+1) | 12(+1) | 19(+4) |



# Story 
## Personal Life
Het verhaal begint op de [[Astral Plane]] waar hij door een krachtige magie de kracht heeft om door planes te reizen maar dan reist hij plotseling in een gevangeniscel waar hij zijn ability verliest en nu vast zit. In dit lab wordt hij geexperimenteerd en na een paar jaar lukt hem op een pijnlijke manier te ontsnappen. Hierna ging [[Dan]] 15 jaar lang reizen in de zee van tijd waar hij niet ouder werd. En toen viel hij er door en kwam hij terecht in een tavern [[Drunk Tard]].
## Professional Life
[[Dan]] werkt niet hij is 15 jaar en leeft op geld dat hij verdient samen met [[Whispers]] door taken die ze doen voor mensen. Zijn professionele is ook zijn persoonlijke leven.



## Background
```ad-warning
title: Message
collapse: open
color: 254, 200, 152
icon: book
De reden dat dit onbekend is doordat hij vanuit zijn plane letterlijk gezakt is naar andere planes en 15 jaar in de tijdloze zee heeft gevaard. Zijn echte leeftijd is UNKNOWN 
```

**Birth Date**: UNKNOWN 
**Marriage Date**: UNKNOWN 
**Death Date**: Has not occured yet
## Additional Details


