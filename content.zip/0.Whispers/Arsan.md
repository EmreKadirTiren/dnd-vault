---
title: Arsan
Draft: 
tags:
  - Category/Individual
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
## Overview
**Alignment**: Chaotic Good
**Gender**: Female
**Race**: Human (secretly a half-elf)
**Class**: Bard
**Age**: 21

**Character Role**: Main Character

| STR   | DEX   | CON   | WIS   | INT   | CHA   |
| ----- | ----- | ----- | ----- | ----- | ----- |
| 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) | 0(+0) |
### Portrait
![[Arsan-20240312091835165.webp|222]]

# Story
## Personal Life

## Professional Life

## Background
**Birth Date**: Monday, 1 January -20000 12:00:00 AM
**Marriage Date**: Monday, 1 January -20000 12:00:00 AM
**Death Date**: Monday, 1 January -20000 12:00:00 AM

## Additional Details

