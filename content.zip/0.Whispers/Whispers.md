---
title: The Whispers
Draft: 
tags:
  - Campaign/Solesticea
  - Category/Party
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
[[Whispers]] is de naam van de part in de campaign [[Solesticea Campaign (Sol)]]. De mensen die bij deze party behoren zijn:
* [[Dan]] gespeeld door [[Emre]] 
* [[Arsan]] gespeeld door [[Anna]] 
* [[Sid]] gespeeld door [[Quinten]] 
* [[Flappie]] gespeeld door [[Olivier]] 
