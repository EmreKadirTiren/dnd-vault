---
title: Dragons of Icespire Peak
Draft: 
tags:
  - "#Category/Campaign"
Publish: false
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
# Dragons of Icespire Peak Overview
 

 
Een module die bij de essentials kit zat en die we alle sessies in het echt gespeeld hebben: 
1. Bij [[Emre]] thuis
2. Bij [[Quinten]] thuis.(Bedankt [[Quinten]] en zijn ouders)

Hierdoor wisten we dat in het echt spelen veel leuker was en dat doen we nu.