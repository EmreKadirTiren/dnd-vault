---
title: Sol 3
Draft: true
tags:
  - timeline
  - SessionJournals
  - "#Session_3"
  - Category/Sessions
Publish: false
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
Session: "3"
---


## Characters + Tips
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
## Session Overview 
 
Brief session overview.

## Informatie en Ontdekkingen

- Description of any important information that the party learned.
- 
- 
 
## Ontmoetingen
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
## Items Of Importance
 
- Description
- 
- 

## Wat werkt
 
- Small description.
- 
- 
- 
## Session Note