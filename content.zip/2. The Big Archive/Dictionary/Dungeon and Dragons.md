---
title: Dungeons and Dragons
Draft: 
tags:
  - DnD
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
[[Dungeon and Dragons]]  is een fantasie-rolspel waarin spelers avonturen beleven in een door de spelleider gecreëerde wereld. Spelers creëren personages met unieke vaardigheden en eigenschappen en nemen deel aan verhalen die zich ontvouwen via dobbelsteenworpen en verbeeldingskracht. Het spel combineert elementen van strategie, improvisatie en samenwerking om een ​​meeslepende en creatieve spelervaring te bieden. De [[DM]] vertelt een verhaal en de spelers vertellen dan wat ze willen doen.