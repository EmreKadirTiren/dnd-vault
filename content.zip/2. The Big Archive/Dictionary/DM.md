---
title: DM
Draft: 
tags:
  - DnD
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
Dungeon Master ook wel Game Master is een persoon die een [[Dungeon and Dragons]] sessie host. Hij vertelt het verhaal en is een sort scheidsrechter