---
title: Emre Kadir
Draft: false
tags:
  - Category/Player
  - "#Player/Emre"
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
[[Emre]] is een van de spelers die meedoet aan D&D ze is deel van de Kluizenaren. Oprichter en schrijver van deze site.

Hij heeft de volgende campaigns gerund:
* [[Dragons of Stormwreck Isle]] (Module)
* [[Dragons of Icespire Peak]] (Module)

En speelde in de volgende campaigns:
* [[Solesticea Campaign (Sol)]] 