---
title: Quinten
Draft: false
tags:
  - Category/Player
  - Player/Quinten
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
 [[Quinten]] is een van de spelers die meedoet aan D&D ze is deel van de Kluizenaren.

```ad-question
Heeft hij echt in [[Dragons of Stormwreck Isle]] campaign gespeeld???
```


 
 En speelde als speler in de volgende campaigns: 
* [[Dragons of Stormwreck Isle]] 
* [[Dragons of Icespire Peak]] 

C'EST OKE!  :)
J'AGREE 