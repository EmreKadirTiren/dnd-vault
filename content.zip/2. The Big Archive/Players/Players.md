# Players Overview
 
```ccard
type: folder_brief_live
```
 
