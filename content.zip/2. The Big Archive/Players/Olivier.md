---
title: Olivier
Draft: false
tags:
  - Category/Player
  - "#Player/Olivier"
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
[[Olivier]]  is een van de spelers die meedoet aan D&D ze is deel van de Kluizenaren.

En speelde als speler in de volgende campaigns: 
* [[Dragons of Stormwreck Isle]] 
* [[Dragons of Icespire Peak]] 
* [[Solesticea Campaign (Sol)]] 

C'EST OKE!  :)