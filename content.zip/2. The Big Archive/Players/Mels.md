---
title: Mels
Draft: false
tags:
  - "#Category/Player"
  - "#Player/Mels"
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
[[Mels]] is een van de spelers die meedoet aan D&D ze is deel van de Kluizenaren. En heeft de volgende campaigns gerund:
* [[Solesticea Campaign (Sol)]] 

En speelde als speler in de volgende campaigns: 
* [[Dragons of Icespire Peak]] 

C'EST OKE!  :)