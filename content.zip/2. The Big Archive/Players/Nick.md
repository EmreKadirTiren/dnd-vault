---
title: Nick
Draft: false
tags:
  - "#Category/Player"
  - Player/Nick
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
[[Nick]] is deel van de Kluizenaren maar doet helaas niet mee aan dnd hij is er soms bij om te luisteren wat er gebeurt en vaak tekent hij iets of schrijft hij namen van random pokemons op.

Hij speelde als speler in de volgende campaigns: 
* [[Dragons of Stormwreck Isle]] 
* [[Dragons of Icespire Peak]] 

C'EST OKE!  :)