---
title: Dorian
Draft: false
tags:
  - Category/Individual
  - Individual/Dorian
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
Alignment: Lawfull Good
Gender: Male
Age: Adult
Race: Human
Class: /
Type: NPC
---
Dorian is de herbergier die werkt en eigenaar is van de [[Drunk Tard]]. Hij is de persoon die gevraagd heeft of ze de kobolds kunnen weghalen. Hij is de hele reden waarom [[Whispers]] bestaan.