---
title: Example Title
Draft: false
tags:
  - Category/Individual
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
Sebastian is de zoon van ... [[Vragen]]