---
title: Snip
Draft: false
tags:
  - Category/Individual
  - "#Individual/Snip"
Publish: true
Author Profile:
  - https://github.com/EmreKadirTiren
Author:
  - Emre Kadir Tiren
---
## Overview
**Alignment**: Neutral
**Gender**: Male
**Race**: Kobold 
**Class**: Rogue
**Age**: Adolecent
**Challenge**: CR 1/8
**Character Role**: Friend

| STR   | DEX    | CON   | WIS   | INT   | CHA   |
| ----- | ------ | ----- | ----- | ----- | ----- |
| 7(-2) | 15(+2) | 9(-1) | 7(-2) | 8(-1) | 8(-1) |

```statblock

monster: Kobold

```


