# Non-Player Characters Overview
 
```ccard
type: folder_brief_live
```
 
