---
title: Crimson Whispers
Draft: true
tags:
  - Category/Group--Criminal
Publish: false
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
Dieven guilde waar [[Flappie]] lid van is # Template - Group: Criminal
