---
title: Eldernax
Draft: false
tags:
  - Category/Group--Religious
  - Group/Eldernax
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Type: Religious
Alignment: Chaotic Evil
Religious-Organization: Order of Evil Scientist
parent:
  - Group_ Religious
up:
  - Group_ Religious
prev:
  - Template - Group_ Other
next:
  - Template - Adventure Area
RWtopicId: Topic_19
---
## Overview
**Type**: Religious

**Alignment**: Chaotic Evil,

**Religious Organization**: Order of Evil Scientist



### Placeholder Iconography
![[Eldernax-20240321200811086.webp|250]]
## Profile
Placeholder

## Story
Placeholder

## Faith and Beliefs
De [[Eldernax]] zijn doel is om wapens te bouwen zodat alle Elfs gedood kunnen worden want wat zijn zij nou waard? Inderdaad helemaal niks.



## Organization
**Headquarters**: UNKNOWN

**Leader(s)**: UNKNOWN 

**Prominent Members**: UNKNOWN 

## Resources
The Kingdom of ... heeft de [[Eldernax]] opgezet en geeft toegang tot alle resources. De Eldernax wordt gefund door [[Arcanum Retreat]] hoort het onder [[Lucrum Dominion]] die de eldernax ook sponsored.

## Methods
Elfen moeten dood ook al leiden andere soorten er door.

## Background


## Additional Details
Deze groep behoort bij de [[Solesticea Campaign (Sol)]], en kwam voor het eerst voor in de derde sessie:[[Sol 3]].

