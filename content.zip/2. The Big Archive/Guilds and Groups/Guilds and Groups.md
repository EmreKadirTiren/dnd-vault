# Guilds and Groups Overview
 
```ccard
type: folder_brief_live
```
 
