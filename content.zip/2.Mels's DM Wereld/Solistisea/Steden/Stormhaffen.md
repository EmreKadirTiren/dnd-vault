---
title: Sturhaffen
Draft: false
tags:
  - Category/Settlement
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
```leaflet 
id: Solesticea_map
image: [[Solesticea_map.png]] 
height: 500px 
lat: 50 
long: 50 
minZoom: -1.5
maxZoom: 1.5
defaultZoom: 1
unit: meters 
scale: 1 
darkMode: false 
```
[[Solesticea]]
 
[[Stormhaffen]] de stad na [[Crestfall]] en ligt in het continent [[Solesticea]] hier hebben we de [[Crimson Whispers]] ontmoet en natuurlijk niet te vergeten [[Bartok]]. [[Stormhaffen]] zit op het meest noordwestelijke puntje van [[Solesticea]].