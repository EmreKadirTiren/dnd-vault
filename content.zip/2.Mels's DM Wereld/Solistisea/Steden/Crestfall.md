---
title: Crestfall
Draft: false
tags:
  - Category/Settlement
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
```leaflet 
id: Solesticea_map
image: [[Solesticea_map.png]] 
height: 500px 
lat: 50 
long: 50 
minZoom: -1.5
maxZoom: 1.5
defaultZoom: 1
unit: meters 
scale: 1 
darkMode: false 
```
[[Solesticea]]
 
[[Crestfall]] is een stad in het continent [[Solesticea]]. Het is de stad waar de [[Whispers]] elkaar ontmoet hebben. [[Crestfall]] ![[Crestfall-20240331213811742.webp]]