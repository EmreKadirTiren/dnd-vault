---
title: Regelheim
Draft: false
tags:
  - Category/Settlement
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
```leaflet 
id: Solesticea_map
image: [[Solesticea_map.png]] 
height: 500px 
lat: 50 
long: 50 
minZoom: -1.5
maxZoom: 1.5
defaultZoom: 1
unit: meters 
scale: 1 
darkMode: false 
```
[[Solesticea]]

[[Regelheim]] de stad na [[Stormhaffen]] hier kwamen we in [[Sol 5]] aan. En hier hebben we gevochten in de arena. En vele hoog machtigen ontmoet van de dievenwereld zoals bijvoorbeeld [[Bloodcloak]].