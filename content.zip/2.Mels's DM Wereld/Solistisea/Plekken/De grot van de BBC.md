---
title: De grot van de BBC
Draft: false
tags:
  - Category/Scene
  - "#Category/Place"
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
Stad/Dorp: Crestfall
---
[[De grot van de BBC]] is een plek waar de Kobolds gingen wonen nadat ze verjaagd waren uit het [[Bos van Crestfall]] door de [[Kobold Monster]] in [[Sol 1]].