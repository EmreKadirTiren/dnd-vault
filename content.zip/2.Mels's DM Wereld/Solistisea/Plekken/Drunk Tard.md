---
title: Drunk Tard
Draft: false
tags:
  - Category/Place
  - Campaign/Solesticea
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
DE PLEK waar het allemaal begon. De herberg die in [[Crestfall]] ligt waar de [[Whispers]] elkaar ontmoeten. De eigenaar van de herberg is [[Dorian]].