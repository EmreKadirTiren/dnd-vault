---
title: Bos van Crestfall
Draft: false
tags:
  - "#Category/Place"
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
Stad/Dorp:
---
# Bos van Crestfall
Dit is de bos waar [[Dan]], [[Flappie]] en Arsan een nacht hebben geslapen en waar de [[Whispers]] de [[Kobold Monster]] gedood hebben. 