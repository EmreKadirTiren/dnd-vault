---
title: Auction Huis
Draft: false
tags:
  - "#Category/Place"
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
Stad/Dorp: Sturhaffen
---
Het Auction Huis ligt in [[Stormhaffen]] en hier werd de gem van de [[Crimson Whispers]] geveild. Waarbij de [[Whispers]] die gem moesten stelen in [[Sol 2]]. Waarbij [[Arsan]] helaas overleed.