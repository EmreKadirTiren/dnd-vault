---
title: Astral Plane
Draft: false
tags:
  - "#Category/Plane"
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
# Astral Plane
Astral Plane in Dungeons & Dragons is een eindeloze ruimte gevuld met lucht en wind, waar zwaartekracht minder voelbaar is. Avonturiers kunnen zweven tussen gigantische luchtstromen en wolkenformaties, terwijl ze worden geconfronteerd met luchtwezens en luchtpiraten. Verkenning van deze planeet vereist vaak magische middelen zoals vliegspells of magische vliegende voorwerpen.


### Wezens die er leven
1. Luchtelementalen
2. Sky Whales
3. Air Sylphs
4. Cloud Rays
5. Thunderbirds
6. Aarakocra