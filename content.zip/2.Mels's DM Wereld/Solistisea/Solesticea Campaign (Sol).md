---
title: Solesticea Campaign (Sol)
Draft: 
tags:
  - Campaign/Solesticea
  - DnD
  - Category/Map
Publish: true
Author:
  - Emre Kadir Tiren
Author Profile:
  - https://github.com/EmreKadirTiren
---
[[Solesticea Campaign (Sol)]] is de campaign dat is bedacht een uitgevoerd door DM [[Mels]]. Het is een van de continenten. Volgens [[Mels]] is elk continent een campaign. Wat we nu alleen weten is dat [[Solesticea Campaign (Sol)]] de eerste campaign is die [[Mels]] gerund heeft maar zeker niet de laatse.